-- MySQL dump 10.13  Distrib 8.0.44, for Linux (x86_64)
--
-- Host: localhost    Database: dosatronon_catalog
-- ------------------------------------------------------
-- Server version	8.0.44-cll-lve

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `medicator`
--

DROP TABLE IF EXISTS `medicator`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `medicator` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `d_dosing` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `performance` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `pressure` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `temperature` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `connections` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `m_seal` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `m_case` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `dop` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `img` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `diag` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `pdf` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `opis` varchar(1000) COLLATE utf8mb4_general_ci NOT NULL,
  `filtr` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medicator`
--

LOCK TABLES `medicator` WRITE;
/*!40000 ALTER TABLE `medicator` DISABLE KEYS */;
INSERT INTO `medicator` (`id`, `name`, `d_dosing`, `performance`, `pressure`, `temperature`, `connections`, `m_seal`, `m_case`, `dop`, `img`, `diag`, `pdf`, `opis`, `filtr`) VALUES (1,'Dosatron DIA4AL VF',' 0.2 — 2 % [1:500 — 1:50]','10 л/ч — 2.5 м³/ч [0.16 — 41.66 л/мин]','0.3 — 6 бар','5 — 40 °C','G¾» наружная','VITON – для кислот, масел, ветеринарных препаратов, ароматических веществ и пестицидов','Полиацеталь','-','medikator.jpg','diag.jpg','pasp.pdf','DIA4AL (серия Animal Health Line) – это новейшая разработка компании Dosatron и новое слово в неэлектрическом пропорциональном дозировании. Уникальный мембранный двигатель позволяет решить ряд принципиальных проблем дозирования препаратов в птицеводстве и свиноводсте. Дозаторон может работать при чрезвычайно малом расходе воды, что делает его незаменимым для поения молодняка. Низкое рабочее давление позволяет использовать его даже в системе с водонапорным баком на высоте всего 1.5 метра. А конструкция двигателя с минимальным количеством деталей подверженных трению, делает возможным применение дозатрона DIA4AL даже если поступающая вода имеет высокое содержание минеральных примесей.','DIA'),(2,'Dosatron D07RE125AF','0.15 — 1.25 % [1:666 — 1:80]','5 л/ч — 0.7 м³/ч [0.08 — 11.66 л/мин]','0.3 — 6 бар','5 — 40 °C','G¾\" наружная','AFLAS – уплотнения, устойчивые к щелочам, для дозирования жидкостей со значением pH более 8','Полиацеталь','Встроенный by-pass','D07RE125AF.jpg','diag.jpg','pasp.pdf','Серия D07 Compact – это самые малогабаритные неэлектрические пропорциональные дозаторы. Их используют в тех случаях, когда не требуется высокая производительность и сильно ограничено пространство для установки. Часто находят свое применение в составе более сложных агрегатов.','D07'),(3,'Dosatron D07RE5AF','0.8 — 5.5 % [1:128 — 1:28]','5 л/ч — 0.7 м³/ч [0.08 — 11.66 л/мин]','0.3 — 6 бар','5 — 40 °C','G¾\" наружная','AFLAS – уплотнения, устойчивые к щелочам, для дозирования жидкостей со значением pH более 8','Полиацеталь','Встроенный by-pass','D07RE5AF.jpg','diag.jpg','pasp.pdf','Серия D07 Compact – это самые малогабаритные неэлектрические пропорциональные дозаторы. Их используют в тех случаях, когда не требуется высокая производительность и сильно ограничено пространство для установки. Часто находят свое применение в составе более сложных агрегатов.','D07');
/*!40000 ALTER TABLE `medicator` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'dosatronon_catalog'
--

--
-- Dumping routines for database 'dosatronon_catalog'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-01-06 14:03:21
